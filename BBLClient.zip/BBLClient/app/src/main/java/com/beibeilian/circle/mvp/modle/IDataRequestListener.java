package com.beibeilian.circle.mvp.modle;


public interface IDataRequestListener {

	public void loadSuccess(Object object);
}
