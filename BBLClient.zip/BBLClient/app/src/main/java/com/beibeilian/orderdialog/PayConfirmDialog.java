package com.beibeilian.orderdialog;


import com.sevengjy.android.app.R;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;

public class PayConfirmDialog extends Dialog {

	public PayConfirmDialog(Context context) {
		super(context);
	}

	public PayConfirmDialog(Context context, int theme) {
		super(context, theme);
	}

	public static class Builder {
		private Context context;

		private DialogInterface.OnClickListener positiveButtonClickListener;

		public Builder(Context context) {
			this.context = context;
		}

		/**
		 * Set the positive button resource and it's listener
		 * 
		 * @param positiveButtonText
		 * @return
		 */
		public Builder setPositiveButton(DialogInterface.OnClickListener listener) {
			this.positiveButtonClickListener = listener;
			return this;
		}

		public PayConfirmDialog create() {
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			final PayConfirmDialog dialog = new PayConfirmDialog(context,R.style.PublicDialogStyle);
			View layout = inflater.inflate(R.layout.pay_confirm_dialog, null);
			dialog.addContentView(layout, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
			// dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			if (positiveButtonClickListener != null) {
				((Button) layout.findViewById(R.id.pay_determine))
						.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) {
								positiveButtonClickListener.onClick(dialog, DialogInterface.BUTTON_POSITIVE);
							}
						});
				((Button) layout.findViewById(R.id.pay_cancel))
				.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						positiveButtonClickListener.onClick(dialog, DialogInterface.BUTTON_POSITIVE);
					}
				});
			}

			dialog.setContentView(layout);
			return dialog;
		}

	}
}
