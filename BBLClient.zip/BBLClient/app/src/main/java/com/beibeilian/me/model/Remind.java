package com.beibeilian.me.model;

public class Remind {

	public String voice;

	public String zhendong;

	public String getVoice() {
		return voice;
	}

	public void setVoice(String voice) {
		this.voice = voice;
	}

	public String getZhendong() {
		return zhendong;
	}

	public void setZhendong(String zhendong) {
		this.zhendong = zhendong;
	}

}
