package com.beibeilian.model;

public class PayRule {

	private String visit;

	private String anlian;

	private String relation;

	private String gift;

	private String marriage;

	private String ball;

	private String chat;

	private String price_15;

	private String price_30;

	private String price_180;

	private String price_360;

	private String ext1Title;

	private String ext1Url;

	private String ext2Title;

	private String ext2Url;

	public String getVisit() {
		return visit;
	}

	public void setVisit(String visit) {
		this.visit = visit;
	}

	public String getAnlian() {
		return anlian;
	}

	public void setAnlian(String anlian) {
		this.anlian = anlian;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getGift() {
		return gift;
	}

	public void setGift(String gift) {
		this.gift = gift;
	}

	public String getMarriage() {
		return marriage;
	}

	public void setMarriage(String marriage) {
		this.marriage = marriage;
	}

	public String getBall() {
		return ball;
	}

	public void setBall(String ball) {
		this.ball = ball;
	}

	public String getChat() {
		return chat;
	}

	public void setChat(String chat) {
		this.chat = chat;
	}

	public String getPrice_15() {
		return price_15;
	}

	public void setPrice_15(String price_15) {
		this.price_15 = price_15;
	}

	public String getPrice_30() {
		return price_30;
	}

	public void setPrice_30(String price_30) {
		this.price_30 = price_30;
	}

	public String getPrice_180() {
		return price_180;
	}

	public void setPrice_180(String price_180) {
		this.price_180 = price_180;
	}

	public String getPrice_360() {
		return price_360;
	}

	public void setPrice_360(String price_360) {
		this.price_360 = price_360;
	}

	public String getExt1Title() {
		return ext1Title;
	}

	public void setExt1Title(String ext1Title) {
		this.ext1Title = ext1Title;
	}

	public String getExt1Url() {
		return ext1Url;
	}

	public void setExt1Url(String ext1Url) {
		this.ext1Url = ext1Url;
	}

	public String getExt2Title() {
		return ext2Title;
	}

	public void setExt2Title(String ext2Title) {
		this.ext2Title = ext2Title;
	}

	public String getExt2Url() {
		return ext2Url;
	}

	public void setExt2Url(String ext2Url) {
		this.ext2Url = ext2Url;
	}

}
