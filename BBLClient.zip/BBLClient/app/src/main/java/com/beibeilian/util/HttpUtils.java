package com.beibeilian.util;

import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

public class HttpUtils {

	public static HttpClient httpClient;

	public static void sendPost(final String url, final Map<String, String> map, final HttpCallback mHttpCallback) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					HttpParams httpParams = new BasicHttpParams();
					HttpConnectionParams.setConnectionTimeout(httpParams, 2 * 60 * 1000);
					HttpConnectionParams.setSoTimeout(httpParams, 2 * 60 * 1000);
					httpClient = new DefaultHttpClient(httpParams);
					HttpPost post = new HttpPost(url);
					List<NameValuePair> params = new ArrayList<NameValuePair>();
					for (String key : map.keySet()) {
						params.add(new BasicNameValuePair(key, map.get(key)));
					}
					post.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
					HttpResponse httpResponse = httpClient.execute(post);
					if (httpResponse.getStatusLine().getStatusCode() == 200) {
						String result = EntityUtils.toString(httpResponse.getEntity());
						mHttpCallback.postSuccess(result);
					}
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					mHttpCallback.failed(e.toString());
				}
			}
		}).start();
	}

	public static void sendGet(final String url, final HttpCallback mHttpCallback) {
		new Thread(new Runnable() {
			@Override
			public void run() {

				try {
					Thread.sleep(3000);
					KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
					trustStore.load(null, null);

					SSLSocketFactory sf = new SSLSocketFactoryImp(trustStore);
					sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
					SchemeRegistry registry = new SchemeRegistry();
					registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
					registry.register(new Scheme("https", sf, 443));// SSL/TSL的认证过程，端口为443

					HttpParams httpParams = new BasicHttpParams();
					HttpConnectionParams.setConnectionTimeout(httpParams, 2 * 60 * 1000);
					HttpConnectionParams.setSoTimeout(httpParams, 2 * 60 * 1000);
					ClientConnectionManager ccm = new ThreadSafeClientConnManager(httpParams, registry);
					httpClient = new DefaultHttpClient(ccm, httpParams);
					HttpGet get = new HttpGet(url);
					HttpResponse httpResponse = httpClient.execute(get);
					if (httpResponse.getStatusLine().getStatusCode() == 200) {
						String result = EntityUtils.toString(httpResponse.getEntity());
						mHttpCallback.getSuccess(result);
					}
				} catch (Exception e) {
					e.printStackTrace();
					mHttpCallback.failed(e.toString());
				}
			}
		}).start();
	}

}
