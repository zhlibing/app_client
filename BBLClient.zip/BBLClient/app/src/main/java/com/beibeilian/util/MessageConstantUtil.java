package com.beibeilian.util;

public class MessageConstantUtil {

	public static final String OUT_SEND_ING="0"; //正在发送中
	
	public static final String OUT_SEND_SUCCESS="1"; //发送成功

	public static final String OUT_SEND_FAILE="-1";  //发送失败

	public static final String SEE_STATE_NO="0";  //消息未查看

	public static final String SEE_STATE_YES="1";  //消息已查看

	
	
}
