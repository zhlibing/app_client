package com.beibeilian.im.video;

public class MyReceiver {
	public static final String STARTPOP = "STARTPOP";
	public static final String ACTION_VIDEO = "ACTION_VIDEO";
	public static final String ACTION_VIDEO_VIP = "ACTION_VIDEO_VIP";
}
