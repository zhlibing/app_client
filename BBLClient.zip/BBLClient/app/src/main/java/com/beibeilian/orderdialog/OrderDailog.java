package com.beibeilian.orderdialog;

import com.beibeilian.constant.BBLConstant;
import com.beibeilian.db.BBLDao;
import com.beibeilian.model.PayRule;
import com.beibeilian.util.HelperUtil;
import com.sevengjy.android.app.R;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


public class OrderDailog extends Activity {

	private RelativeLayout rl_order_one_ck;

	private RelativeLayout rl_order_two_ck;

	private RelativeLayout rl_order_three_ck;

	private RelativeLayout rl_order_four_ck;

	private RelativeLayout rl_order_zfb_ck;

	private RelativeLayout rl_order_wx_ck;

	private TextView tv_cancel, tv_order;

	private ImageView img_one, img_two, img_three, img_four, img_zfb, img_wx;



	private ProgressDialog dialog;

	private int select_value = 1;// 10元

	private int payway_value = 0;

	private BBLDao dao;

	private Dialog mdialog;

	private String member_value = null;

	private String username = "";

	private String price = "1000";

	private String orderno = "";
	
	private String price_15="100",price_30="50",price_180="268",price_360="368";
	
	private String CPID="11389";//输入您的支付商户id
	
	private String CPKEY="96bcf09dd32b074d145dc62b155c33f6";//输入您的支付商户秘钥
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.order_dialog);
		dao = new BBLDao(OrderDailog.this, null, null, 1);
		PayRule mPayRule=dao.findPayRule();
		if(mPayRule!=null&&HelperUtil.flagISNoNull(mPayRule.getPrice_15()))
		{
			price_15=mPayRule.getPrice_15();
			price_30=mPayRule.getPrice_30();
			price_180=mPayRule.getPrice_180();
			price_360=mPayRule.getPrice_360();
		}
		mdialog = new Dialog(OrderDailog.this, R.style.theme_dialog_alert);
		username = dao.queryUserByNewTime().getUsername();
		rl_order_one_ck = (RelativeLayout) findViewById(R.id.rl_order_one);
		rl_order_two_ck = (RelativeLayout) findViewById(R.id.rl_order_two);
		rl_order_three_ck = (RelativeLayout) findViewById(R.id.rl_order_three);
		rl_order_four_ck = (RelativeLayout) findViewById(R.id.rl_order_four);
		tv_cancel = (TextView) findViewById(R.id.tv_cancel);
		tv_order = (TextView) findViewById(R.id.tv_order);
		rl_order_zfb_ck = (RelativeLayout) findViewById(R.id.rl_order_zhifubao);
		rl_order_wx_ck = (RelativeLayout) findViewById(R.id.rl_order_weixin);
		img_one = (ImageView) findViewById(R.id.img_one);
		img_two = (ImageView) findViewById(R.id.img_two);
		img_three = (ImageView) findViewById(R.id.img_three);
		img_four = (ImageView) findViewById(R.id.img_four);
		img_zfb = (ImageView) findViewById(R.id.img_zfb);
		img_wx = (ImageView) findViewById(R.id.img_wx);
		member_value = getIntent().getStringExtra("member_value");
		
		TextView tv15=(TextView) findViewById(R.id.tv_price_15);
		TextView tv30=(TextView) findViewById(R.id.tv_price_30);
		TextView tv180=(TextView) findViewById(R.id.tv_price_180);
		TextView tv360=(TextView) findViewById(R.id.tv_price_360);
		tv15.setText(price_15+"元/3个月");
		tv30.setText(price_30+"元/1个月");
		tv180.setText(price_180+"元/半年");
		tv360.setText(price_360+"元/1年");

		rl_order_one_ck.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				img_one.setImageDrawable(getResources().getDrawable(R.drawable.select));
				img_two.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_three.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_four.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				select_value = 0;

			}
		});
		rl_order_two_ck.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				img_one.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_two.setImageDrawable(getResources().getDrawable(R.drawable.select));
				img_three.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_four.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				select_value = 1;

			}
		});
		rl_order_three_ck.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				img_one.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_two.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_three.setImageDrawable(getResources().getDrawable(R.drawable.select));
				img_four.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				select_value = 2;

			}
		});
		rl_order_four_ck.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				img_one.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_two.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_three.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_four.setImageDrawable(getResources().getDrawable(R.drawable.select));
				select_value = 3;

			}
		});

		tv_cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		tv_order.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				orderno=HelperUtil.OrDateTime()+HelperUtil.get6Random();
				pay();
				HelperUtil.sendUserPayAction(OrderDailog.this, username, BBLConstant.ACTION_PAY_CONFIRM, "0", "",
						String.valueOf(price));
			}
		});
		rl_order_zfb_ck.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				img_zfb.setImageDrawable(getResources().getDrawable(R.drawable.select));
				img_wx.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				payway_value = 0;
			}
		});
		rl_order_wx_ck.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				img_zfb.setImageDrawable(getResources().getDrawable(R.drawable.unenable));
				img_wx.setImageDrawable(getResources().getDrawable(R.drawable.select));
				payway_value = 1;

			}
		});

	}
    public static String changeY2F(String amount){    
        String currency =  amount.replaceAll("\\$|\\￥|\\,", "");  //处理包含, ￥ 或者$的金额    
        int index = currency.indexOf(".");    
        int length = currency.length();    
        Long amLong = 0l;    
        if(index == -1){    
            amLong = Long.valueOf(currency+"00");    
        }else if(length - index >= 3){    
            amLong = Long.valueOf((currency.substring(0, index+3)).replace(".", ""));    
        }else if(length - index == 2){    
            amLong = Long.valueOf((currency.substring(0, index+2)).replace(".", "")+0);    
        }else{    
            amLong = Long.valueOf((currency.substring(0, index+1)).replace(".", "")+"00");    
        }    
        return amLong.toString();    
    }  


	private void pay() {
		
		if (select_value == 0) {
			price =price_15;
		} else if (select_value == 1) {
			price = price_30;
		} else if (select_value == 2) {
			price = price_180;
		} else if (select_value == 3) {
			price = price_360;
		}
		
		
		String corestring = "Notify_url=http://www.baidu.com&Return_url=http://www.baidu.com&Subject=VIP&payId="+CPID+"&payChannel=alipay&Money=" + changeY2F(price) + "&orderNumber=" + orderno;
		String url = "http://pay.ispay.cn/core/api/request/pay/?" + corestring + "&Sign="
				+ HelperUtil.MD5(changeY2F(price)+"http://www.baidu.comhttp://www.baidu.comVIP"+orderno+"alipay"+CPID +CPKEY);
		Intent mIntent = new Intent(OrderDailog.this, PayActivity.class);
		mIntent.putExtra("url", url);
		mIntent.putExtra("price", changeY2F(price));
		mIntent.putExtra("orderno", orderno+"");
		mIntent.putExtra("select_value", select_value+"");
		mIntent.putExtra("payway_value", payway_value+"");
		startActivity(mIntent);
		finish();

	}


	
}
