package com.beibeilian.circle.spannable;


public interface ISpanClick {
    public void onClick(int position);
}
