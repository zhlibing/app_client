package com.beibeilian.photo.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


import android.app.Activity;
import android.graphics.BitmapFactory;


public class PublicWay {
	public static List<Activity> activityList = new ArrayList<Activity>();
	
	public static int num = 9;
	
}
