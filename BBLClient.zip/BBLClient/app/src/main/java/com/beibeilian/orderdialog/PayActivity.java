package com.beibeilian.orderdialog;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONObject;

import com.beibeilian.db.BBLDao;
import com.beibeilian.receiver.ReceiverConstant;
import com.beibeilian.util.HelperUtil;
import com.beibeilian.util.HttpCallback;
import com.beibeilian.util.HttpConstantUtil;
import com.beibeilian.util.HttpUtils;
import com.beibeilian.util.PreferencesUtils;
import com.beibeilian.util.SweetAlertDialog;
import com.sevengjy.android.app.R;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

public class PayActivity extends Activity {

	private WebView mWebView;
	private TextView tvWEBtitle;
	private String url;
	private SweetAlertDialog dialog;
	// 需要保存图片的路径
	private boolean isActivityResult = false;// 记录是否走到这个方法
	private final int PAY_FAILED = 0;
	private final int PAY_SUCCESS = 1;
	private final int CODE_LOAD_FINISH = 100;
	private String price;
	private String orderno = "";
	private PayConfirmDialog mConfirmDialog;
	private void showDialog() {
		try {
			if (dialog == null) {
				dialog = new SweetAlertDialog(PayActivity.this);
				dialog.setCancelable(false);
			}
			dialog.setTitle("请稍候...");
			dialog.show();
		} catch (Exception e) {
			// 在其他线程调用dialog会报错
		}
	}

	private void hideDialog() {
		if (dialog != null && dialog.isShowing())
			try {
				dialog.dismiss();
			} catch (Exception e) {
			}
	}

	private BBLDao mDAO;
	private String payway_value,select_value;
	
	private String CPID="11389";//输入您的支付商户id
	
	private boolean ispay=false;
	
	private boolean isopenalipay=false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wap);
		mDAO=new BBLDao(PayActivity.this, null, null, 1);
		mWebView = (WebView) findViewById(R.id.webview);
		tvWEBtitle = (TextView) findViewById(R.id.web_title);
		tvWEBtitle.setText("支付宝支付");
		Button btnBack = (Button) findViewById(R.id.btnBack);
		url = getIntent().getStringExtra("url");
		price = getIntent().getStringExtra("price");
		orderno = getIntent().getStringExtra("orderno");
        payway_value=getIntent().getStringExtra("payway_value");
        select_value=getIntent().getStringExtra("select_value");

		btnBack.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		showDialog();
		initViews();

	}



	private Timer timer;
	private long timeout = 20 * 1000;
	private boolean isCallBack=false;
	

	private void initViews() {

		CookieSyncManager.createInstance(this);
		CookieManager.getInstance().removeAllCookie();
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setAppCacheEnabled(false);
		mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
		mWebView.getSettings().setBlockNetworkImage(false);
		mWebView.getSettings().setBlockNetworkLoads(false);
		mWebView.clearCache(true);
		mWebView.getSettings().setRenderPriority(RenderPriority.HIGH);
		mWebView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
		mWebView.getSettings().setUseWideViewPort(true);
		mWebView.getSettings().setSavePassword(true);
		mWebView.getSettings().setSaveFormData(true);
		mWebView.getSettings().setDomStorageEnabled(true);
		mWebView.requestFocus();
		WebChromeClient wvcc = new WebChromeClient() {
			@Override
			public void onReceivedTitle(WebView view, String title) {
				super.onReceivedTitle(view, title);
			}
		};
		mWebView.setWebChromeClient(wvcc);
		mWebView.loadUrl(url);
		
		// 设置Web视图
		mWebView.setWebViewClient(new WebViewClient() {

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				timer = new Timer();
				TimerTask tt = new TimerTask() {
					@Override
					public void run() {
						new Handler(PayActivity.this.getMainLooper()).post(new Runnable() {
							@Override
							public void run() {
								if (mWebView.getProgress() < 100) {
									hideDialog();
									if (timer != null) {
										timer.cancel();
										timer.purge();
									}
								}
							}
						});

					}
				};
				timer.schedule(tt, timeout);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				if (timer != null) {
					timer.cancel();
					timer.purge();
				}
				hideDialog();

			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				
				//Log.e("test", "支付url-->"+url);
				
				if(url!=null&&url.startsWith("https://m.baidu.com"))
				{
//					if(isCallBack||isActivityResult) return true;
//					//mHandler.sendEmptyMessage(PAY_SUCCESS);
//					isCallBack=true;
					return true;
				}
				if (url != null && url.startsWith("alipay://")) {
					try {

						Intent intent;
						intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
						intent.addCategory("android.intent.category.BROWSABLE");
						intent.setComponent(null);
						// intent.setSelector(null);
						startActivity(intent);

					} catch (Exception e) {

					}
					return true;
				}
				if (url != null && url.startsWith("alipays://")) {
					try {
						isopenalipay=true;
						payConfirmOperateDialog();
						Intent intent;
						intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
						intent.addCategory("android.intent.category.BROWSABLE");
						intent.setComponent(null);
						// intent.setSelector(null);
						startActivity(intent);

					} catch (Exception e) {

					}
					return true;
				}
//				if (url != null && url.startsWith("alipay://")) {
//					payConfirmOperateDialog();
//					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
//					startActivityForResult(intent, 100);
//					return true;
//				}

				//view.loadUrl(url);
				return super.shouldOverrideUrlLoading(view, url);
			}

		});

	}

	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {

			case CODE_LOAD_FINISH:
				hideDialog();
				sendBroadcast(new Intent(ReceiverConstant.ME_MEMBER_REFESH_ACTION));
				finish();
				break;
			case PAY_FAILED:

				break;
			case PAY_SUCCESS:
				//startQueryOrderStatus();
				break;
			case 5:
				try {
					if (mConfirmDialog == null) {
						PayConfirmDialog.Builder builder = new PayConfirmDialog.Builder(PayActivity.this);
						builder.setPositiveButton(new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								if(!ispay)
								{
								startQueryOrderStatus();
								}
							}
						});
						mConfirmDialog = builder.create();
						mConfirmDialog.setCancelable(false);
					}
					mConfirmDialog.show();
				} catch (Exception e) {

				}
				break;
			default:
				break;
			}
		}
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {

			finish();
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {

		if (mWebView != null)
			mWebView.destroy();
		super.onDestroy();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		isActivityResult = true;
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void startQueryOrderStatus() {
		showDialog();
		String geturl = "https://pay.ispay.cn/core/api/request/query/?payId="+CPID+"&orderNumber="
				+ orderno;
		HttpUtils.sendGet(geturl, new HttpCallback() {

			@Override
			public void postSuccess(String result) {
				// TODO Auto-generated method stub

			}

			@Override
			public void getSuccess(String result) {
				// TODO Auto-generated method stub
				mHandler.sendEmptyMessage(CODE_LOAD_FINISH);
				final JSONObject jsonObject;
				try {
					jsonObject = new JSONObject(result);
					if (jsonObject.optString("State").equals("success")) {
						PayActivity.this.runOnUiThread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								PreferencesUtils.putString(PayActivity.this, "vip", "1");
								HelperUtil.totastShow("支付成功", getApplicationContext());
								sendOrderInfo("1", "zfb pay success");

							}
						});
					} else {
						PayActivity.this.runOnUiThread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								sendOrderInfo("0", "zfb pay failed");

							}
						});
					}
				} catch (final Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					PayActivity.this.runOnUiThread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							sendOrderInfo("0", "zfb pay unknow");

						}
					});
				}

			}

			@Override
			public void failed(final String result) {
				// TODO Auto-generated method stub
				PayActivity.this.runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						sendOrderInfo("2", "zfb pay unknow:" + result);

					}
				});
			}
		});

	}
	 /**金额为分的格式 */    
    public static final String CURRENCY_FEN_REGEX = "\\-?[0-9]+"; 
	public static String changeF2Y(String amount) throws Exception{    
        if(!amount.matches(CURRENCY_FEN_REGEX)) {    
            throw new Exception("金额格式有误");    
        }    
        return BigDecimal.valueOf(Long.valueOf(amount)).divide(new BigDecimal(100)).toString();    
    }    
	private void sendOrderInfo(final String state,final String errorinfo) {
		
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO AutoS-generated method stub
				try {
					
					Map<String, String> map = new HashMap<String, String>();
					map.put("username", mDAO.queryUserByNewTime().getUsername());
					map.put("payway", String.valueOf(payway_value));
					map.put("membertype", String.valueOf(select_value));
					map.put("orderno", orderno);
					map.put("version", HelperUtil.getVersionCode(PayActivity.this));
					map.put("imie", HelperUtil.getIMIE(PayActivity.this));
					map.put("price", changeF2Y(price));
					map.put("paystate",state);
					map.put("errorinfo",errorinfo);
					map.put("uploadtype","0");
					map.put("channel",HelperUtil.getChannelId(PayActivity.this) );
					map.put("appid",HelperUtil.getAPPlId(PayActivity.this));
					HelperUtil.postRequest(HttpConstantUtil.SendOrderInfo, map);
					mHandler.sendEmptyMessage(CODE_LOAD_FINISH);
				} catch (Exception e) {
					mHandler.sendEmptyMessage(CODE_LOAD_FINISH);
				}
			}
		}).start();

	}
	
	
	private void payConfirmOperateDialog() {
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				mHandler.sendEmptyMessage(5);
			}
		}, 3000);

	}
   
	

	@Override
	protected void onRestart() {
		super.onRestart();
            if(isopenalipay)
            {
			ispay=true;
			startQueryOrderStatus();
            }
	}
}
