package com.beibeilian.util;


public interface HttpCallback {

	public void postSuccess(String result);
	
	public void getSuccess(String result);
	
	public void failed(String result);
	
}
